# -*- coding: utf-8 -*-
__author__ = u'Vladimír Gorej <vladimir.gorej@gmail.com>'
__version__ = '1.7.0'
